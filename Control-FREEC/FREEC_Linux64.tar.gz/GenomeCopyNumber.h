#ifndef HEADER_4D7F42FDD0838B93
#define HEADER_4D7F42FDD0838B93

#pragma once
#ifndef _GENOME_CPN_H
#define _GENOME_CPN_H

#include <string>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <map>
#include <fstream>
#include "SVfinder.h"

#include "myFunc.h"
#include "ChrCopyNumber.h"
#include "SVfinder.h"
#include "chisquaredistr.h" //to calculate chisquare distribution
#include "EntryCNV.h"
#include "SNPinGenome.h"

class GenomeCopyNumber
{
public:
	GenomeCopyNumber(void);
	~GenomeCopyNumber(void);

	void readCopyNumber(std::string const& mateFileName ,std::string const& inputFormat, std::string const& matesOrientation, std::string const& chrLenFileName, int windowSize, int step );
	void readCopyNumber(std::string const& mateFileName ,std::string const& inputFormat, std::string const& matesOrientation, std::string const& chrLenFileName, float coefficientOfVariation );
	void readCopyNumber(std::string const& inFile);
	int readCGprofile(std::string const& inFile);
	void readGemMappabilityFile(std::string const& inFile);
	int processRead(std::string const& inputFormat, std::string const& matesOrientation,std::string const line);
    int processRead(InputFormat inputFormat, MateOrientation matesOrientation, const char* line_buffer);
	int processReadWithBowtie(std::string const& inputFormat, std::string const& matesOrientation,std::string const line,std::string const line2);
    int focusOnCapture (std::string const& captureFile);
	void initCopyNumber(std::string const& chrLenFileName, int windowSize , int step);
	void finishCopyNumber(long normalCount);
    void addBAFinfo(SNPinGenome snpingenome);
    void removeLowReadCountWindows(GenomeCopyNumber & controlCopyNumber, int RCThresh);


	void calculateRatio( GenomeCopyNumber & controlCopyNumber, int degree, bool intercept,bool logLogNorm) ;
    void calculateRatioUsingCG( GenomeCopyNumber & controlCopyNumber) ;
	float calculateNormalizationConstant(GenomeCopyNumber & controlCopyNumber);
	void calculateBreakpoints(double breakPointThreshold, int breakPointType);
	void calculateBAFBreakpoints(double breakPointThreshold, int breakPointType);
	void calculateSDAndMed(int ploidy,std::map<float,float> &sds,std::map<float,float> &meds);
	void calculateSDs(int ploidy, std::map <float,float> &sds) ; //only SDs
	float calculateVarianceForNormalCopy(int ploidy); //OLD
	void calculatePloidy(int minCNAlength);
	double calculateXiSum(int ploidy); //calculates sum_{i}{(med_i-supposedValue_i) / SQRT(var_i)}   var_i = pi/2/n*sd_i*2 which should be distributed as Xi_sqaure if the null hypo is correct
	void calculateCopyNumberProbs_and_genomeLength(int breakPointType) ;
	void deleteFlanks(int telo_centromeric_flanks);
	void recalcFlanks(int telo_centromeric_flanks, int minNumberOfWindows);
	void calculateRatioUsingCG (int degree, bool intercept, float minExpectedGC, float maxExpectedGC) ;

    void recalculateRatioUsingCG (int degree, bool intercept, float minExpectedGC, float maxExpectedGC) ;
	void recalculateRatio (float contamination);
	void calculateCopyNumberMedians (int minCNAlength, bool noisyData);
	double calculateMedianRatioAround (float interval, float around);
    double calculateMedianAround (float interval, float around);
    void calculateSomaticCNVs (std::vector <EntryCNV> controlCNVs, int controlPloidy);
    int calculateMedianReadCountPerWindow();
    int calculateSDReadCountPerWindow(int mean);

	double calculateMedianAround (GenomeCopyNumber & controlCopyNumber, float interval, float around);
	float evaluateContamination();

	void printRatio(std::string const& outFile, bool ifBedGraphOutPut, bool printNA);
	void printRatio(std::string const& chr, std::string const& outFile, bool printNA);
	void printRatio(std::string const& chr, std::ofstream & file, bool printNA);
    void printRatioBedGraph(std::string const& chr, std::ofstream & file, std::string const& typeCNA);
	void printPloidy(std::string const& outFile) ;
	void printPloidy(std::ofstream & file);
	void printCopyNumber(std::string const& outFile);
	void printCopyNumber(std::string const& chr, std::ofstream & file) ;
	void printCopyNumber(std::string const& chr, std::string const& outFile);
	void printCGprofile(std::string const& outFile);
	void printCGprofile(std::string const& chr, std::ofstream & file);
	void printCNVs (std::string const& outFile);
	void printBAF(std::string const& outFile, SNPinGenome& snpingenome);
    void printBAF(std::string const& chr, std::ofstream & file, SNPatChr& snpAtChrom);



	int findIndex (std::string const& chr);
	void fillCGprofile(std::string const& chrFolder);

	ChrCopyNumber getChrCopyNumber(std::string const& chr);
	float getMedianCopyNumber();
	long getTotalNumberOfPairs();
	float getMedianRatio();
	int getWindowSize(void);
	long getNormalNumberOfPairs();
	std::vector <EntryCNV> getCNVs ();
    int getPloidy();


	void setPloidy(int ploidy);
	void setStep(int step);
    void setBAFtrue();
    void setNormalContamination(float normalContamination) ;
    void setAllNormal ();
    void setSamtools(std::string const& pathToSamtools);

    bool ifHasBAF();
    void setSex(std::string sex);

	ChrCopyNumber& getChrCopyNumberAt(int index) {return chrCopyNumber_[index];}
	int getStep() const {return step_;}
private:
	std::vector<ChrCopyNumber> chrCopyNumber_;
	std::map<std::string, int> chromosomesInd_;
	void fillMyHash(std::string const& mateFileName , std::string const& inputFormat, std::string const& matesOrientation, int windowSize, int step );
	int windowSize_;
	int step_;
	long totalNumberOfPairs_;
	long normalNumberOfPairs_;
	double refGenomeSize_;
	int ploidy_;
	double ploidy_pvalue_;
	double estimationOfGenomeSize_;
	std::map<int, double> copyNumberProbs_;
	int telo_centromeric_flanks_;
	std::vector <EntryCNV> CNVs_;
	bool hasBAF_;
	bool ifUsedControl_;
	float normalContamination_;
	std::string sex_;
	std::string pathToSamtools_;
};
#endif

//
// Multi Thread Support
//

struct GenomeCopyNumberCalculateBreakpointArgWrapper : public ThreadArg {
  GenomeCopyNumber& genomeCopyNumber;
  double breakPointThreshold;
  int breakPointType;

  GenomeCopyNumberCalculateBreakpointArgWrapper(GenomeCopyNumber& genomeCopyNumber, double breakPointThreshold, int breakPointType) : genomeCopyNumber(genomeCopyNumber), breakPointThreshold(breakPointThreshold), breakPointType(breakPointType) { }
};

extern void* GenomeCopyNumber_calculateBreakpoint_wrapper(void *arg);

struct GenomeCopyNumberReadMateFileArgWrapper : public ThreadArg {
  SNPinGenome& snpInGenome;
  std::string mateFile;
  std::string inputFormat;
  int minimalTotalLetterCountPerPosition;
  int minimalQualityPerPosition;
  GenomeCopyNumber* p_genomeCopyNumber;
  std::string chrLenFileName;
  int windowSize;
  int step;

  GenomeCopyNumberReadMateFileArgWrapper(SNPinGenome& snpInGenome, std::string const& mateFile, const std::string& inputFormat, int minimalTotalLetterCountPerPosition, int minimalQualityPerPosition) : snpInGenome(snpInGenome), mateFile(mateFile), inputFormat(inputFormat), minimalTotalLetterCountPerPosition(minimalTotalLetterCountPerPosition), minimalQualityPerPosition(minimalQualityPerPosition), p_genomeCopyNumber(NULL), windowSize(0), step(0) { }

  GenomeCopyNumberReadMateFileArgWrapper(SNPinGenome& snpInGenome, std::string const& mateFile, std::string const& inputFormat, int minimalTotalLetterCountPerPosition, int minimalQualityPerPosition, GenomeCopyNumber& genomeCopyNumber, std::string const& chrLenFileName, int windowSize, int step) :  snpInGenome(snpInGenome), mateFile(mateFile), inputFormat(inputFormat), minimalTotalLetterCountPerPosition(minimalTotalLetterCountPerPosition), minimalQualityPerPosition(minimalQualityPerPosition), p_genomeCopyNumber(&genomeCopyNumber), chrLenFileName(chrLenFileName), windowSize(windowSize), step(step) { }
};

extern void* GenomeCopyNumber_readMateFile_wrapper(void *arg);

#endif // header guard
