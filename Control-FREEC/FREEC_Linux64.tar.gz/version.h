
#ifndef VERSION_H
#define VERSION_H

const double VERSION_OFFSET = 3;
const double FREEC_VERSION = 7.2;
const double CONTROL_FREEC_VERSION = FREEC_VERSION - VERSION_OFFSET;

#endif
